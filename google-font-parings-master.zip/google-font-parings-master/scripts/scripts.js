console.log(typeof $);

$(".hero-content").fadeIn(2500);
